<?php  
 $con = mysqli_connect("localhost","root","","college") or die("Couldn't connect"); 
?> 
