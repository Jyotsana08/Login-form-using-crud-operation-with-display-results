<footer style="font-size:15px; font:weight:600; 
            color:#262A33; 
            margin : 0; 
            text-align:center; 
            padding:20px;">  
            <p>OJT_TASK &copy; Jyotsana Bagul</p> 
</footer> 